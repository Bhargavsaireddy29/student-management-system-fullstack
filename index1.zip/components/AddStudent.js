import React, { useState } from "react";
import axios from "axios";

function AddStudent() {
  const [student, setStudent] = useState({
    name: "",
    city: "",
    email: "",
    password: "", // ✅ added password
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8080/add", student);
      setMessage("✅ Student added successfully!");
      setStudent({ name: "", city: "", email: "", password: "" }); // clear form
    } catch (err) {
      console.error(err);
      setMessage("❌ Error adding student. Please try again.");
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <h2>Add Student</h2>
      <form onSubmit={handleSubmit}>
        <input
          name="name"
          value={student.name}
          onChange={handleChange}
          placeholder="Name"
          required
        />
        <input
          name="city"
          value={student.city}
          onChange={handleChange}
          placeholder="City"
          required
        />
        <input
          name="email"
          value={student.email}
          onChange={handleChange}
          placeholder="Email"
          type="email"
          required
        />
        <input
          name="password"
          value={student.password}
          onChange={handleChange}
          placeholder="Password"
          type="password"
          required
        />
        <button type="submit">Add</button>
      </form>

      {/* Message display */}
      {message && <p style={{ marginTop: "20px", color: "green" }}>{message}</p>}
    </div>
  );
}

export default AddStudent;
