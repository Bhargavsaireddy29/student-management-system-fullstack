import React, { useState } from "react";
import api from "../api";

function SearchStudent() {
  const [name, setName] = useState("");
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);

  const search = async (e) => {
    e.preventDefault();

    if (!name.trim()) {
      alert("Please enter a name!");
      return;
    }

    setLoading(true);
    try {
      const res = await api.get(`/st/${encodeURIComponent(name)}`);
      const data = Array.isArray(res.data) ? res.data : [res.data]; // ensure it's always an array
      setStudents(data);

      if (data.length === 0) {
        alert("No students found!");
      }
    } catch (err) {
      console.error(err);
      alert("Error searching student!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "30px" }}>
      <h2>🔍 Search Student</h2>

      <form onSubmit={search} style={{ marginBottom: "20px" }}>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter Name"
          style={{
            padding: "8px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            marginRight: "10px",
          }}
        />
        <button
          type="submit"
          style={{
            padding: "8px 15px",
            borderRadius: "5px",
            border: "none",
            backgroundColor: "#007bff",
            color: "white",
            cursor: "pointer",
          }}
          disabled={loading}
        >
          {loading ? "Searching..." : "Search"}
        </button>
      </form>

      {students.length > 0 && (
        <div style={{ width: "50%", margin: "0 auto", textAlign: "left" }}>
          <h3>Results:</h3>
          {students.map((stu, index) => (
            <div
              key={index}
              style={{
                backgroundColor: "#f7f7f7",
                margin: "10px 0",
                padding: "10px",
                borderRadius: "8px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
              }}
            >
              <p><b>Name:</b> {stu.name}</p>
              <p><b>City:</b> {stu.city}</p>
              <p><b>Email:</b> {stu.email}</p>
              <p><b>Role:</b> {stu.role}</p>
            </div>
          ))}
        </div>
      )}

      {students.length === 0 && !loading && name && (
        <p>No student found with that name.</p>
      )}
    </div>
  );
}

export default SearchStudent;
