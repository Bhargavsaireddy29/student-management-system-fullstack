import React, { useState, useEffect, useCallback } from "react";
import api from "../api";

export default function PaginatedStudents() {
  const [name, setName] = useState("");
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(5);
  const [students, setStudents] = useState([]);
  const [totalPages, setTotalPages] = useState(0);

  // ✅ Define the function with useCallback so dependency is stable
  const fetchStudents = useCallback(async () => {
    try {
      const res = await api.get(`/student/${encodeURIComponent(name)}`, {
        params: { page, size, sort: "id,asc" },
      });

      const data = res.data;
      setStudents(data.content || data);
      setTotalPages(data.totalPages ?? 0);
    } catch (err) {
      console.error("Error fetching students:", err);
      alert("Error fetching students. Check console for details.");
    }
  }, [name, page, size]); // ✅ Dependencies

  // ✅ Fetch data when dependencies change
  useEffect(() => {
    fetchStudents();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchStudents]); // eslint-disable-next-line avoids rewarning

  // ✅ Manual trigger (button)
  const handleSubmit = (e) => {
    e.preventDefault();
    fetchStudents();
  };

  return (
    <div>
      <h2>Paginated Students</h2>

      <form onSubmit={handleSubmit}>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name filter"
        />
        <input
          type="number"
          value={page}
          onChange={(e) => setPage(Number(e.target.value))}
          min="0"
        />
        <input
          type="number"
          value={size}
          onChange={(e) => setSize(Number(e.target.value))}
          min="1"
        />
        <button type="submit">Fetch</button>
      </form>

      <div>
        <p>Total pages: {totalPages}</p>
        <ul>
          {students.map((s) => (
            <li key={s.id}>
              {s.name} — {s.email} — {s.city}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
