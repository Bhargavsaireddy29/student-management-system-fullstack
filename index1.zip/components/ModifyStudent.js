import React, { useState } from "react";
import api from "../api";

function ModifyStudent() {
  const [email, setEmail] = useState("");
  const [newCity, setNewCity] = useState("");

  const modify = async (e) => {
    e.preventDefault();
    try {
      const res = await api.put(`/update/${encodeURIComponent(email)}`, {
        city: newCity,
      });
      alert(res.data);
    } catch (err) {
      console.error(err);
      alert("Error updating student.");
    }
  };

  return (
    <div>
      <h2>Modify Student</h2>
      <form onSubmit={modify}>
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
        />
        <input
          value={newCity}
          onChange={(e) => setNewCity(e.target.value)}
          placeholder="New City"
        />
        <button type="submit">Update</button>
      </form>
    </div>
  );
}

export default ModifyStudent;
