import React, { useState } from "react";
import api from "../api";

export default function DeleteStudent() {
  const [email, setEmail] = useState("");

  const del = async (e) => {
    e.preventDefault();
    try {
      const res = await api.delete(`/dell/${encodeURIComponent(email)}`);
      alert(res.data);
    } catch (err) {
      console.error(err);
      alert("Error deleting. See console.");
    }
  };

  return (
    <div>
      <h2>Delete Student</h2>
      <form onSubmit={del}>
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
        <button type="submit">Delete</button>
      </form>
    </div>
  );
}
