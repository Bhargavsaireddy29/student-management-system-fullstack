// src/App.js
import { BrowserRouter, Routes, Route, Link, Navigate } from "react-router-dom";
import AddStudent from "./components/AddStudent";
import SearchStudent from "./components/SearchStudent";
import ModifyStudent from "./components/ModifyStudent";
import DeleteStudent from "./components/DeleteStudent";
import PaginatedStudents from "./components/PaginatedStudents";
import Login from "./components/Login";

// ✅ ProtectedRoute component
function ProtectedRoute({ children }) {
  const token = localStorage.getItem("token");
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return children;
}

function App() {
  return (
    <BrowserRouter>
      <div style={{ padding: 20 }}>
        <nav style={{ marginBottom: 10 }}>
          <Link to="/add">Add</Link> |{" "}
          <Link to="/search">Search</Link> |{" "}
          <Link to="/modify">Modify</Link> |{" "}
          <Link to="/delete">Delete</Link> |{" "}
          <Link to="/paginate">Paginate</Link> |{" "}
          <Link to="/login">Login</Link>
        </nav>

        <Routes>
          <Route path="/add" element={<AddStudent />} />
          <Route path="/login" element={<Login />} />

          <Route
            path="/search"
            element={
              <ProtectedRoute>
                <SearchStudent />
              </ProtectedRoute>
            }
          />
          <Route
            path="/modify"
            element={
              <ProtectedRoute>
                <ModifyStudent />
              </ProtectedRoute>
            }
          />
          <Route
            path="/delete"
            element={
              <ProtectedRoute>
                <DeleteStudent />
              </ProtectedRoute>
            }
          />
          <Route
            path="/paginate"
            element={
              <ProtectedRoute>
                <PaginatedStudents />
              </ProtectedRoute>
            }
          />

          <Route path="/" element={<div>Open a page from the menu.</div>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
