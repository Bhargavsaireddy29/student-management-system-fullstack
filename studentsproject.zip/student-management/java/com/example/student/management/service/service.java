package com.example.student.management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.student.management.exception.ResourceNotFoundException;
import com.example.student.management.model.Student;
import com.example.student.management.repository.Studentrepository;

@Service
public class service {

	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	Studentrepository ss;
	
	public Student add(Student s) {
	    if (s.getPassword() == null || s.getPassword().isBlank()) {
	        s.setPassword("default123"); // default password
	    }
	    s.setPassword(passwordEncoder.encode(s.getPassword()));

	    // If role not set, default to STUDENT
	    if (s.getRole() == null || s.getRole().isBlank()) {
	        s.setRole("STUDENT");
	    }

	    return ss.save(s);
	}

	
	public List<Student> findByName(String name )
	{
		return  ss.findByName(name);
		
	}
	public Student putt(String email, String city)
	{
	    Student stu = ss.findByEmail(email);
	    if (stu == null) {
	        throw new ResourceNotFoundException("Student not found with email: " + email);
	    }
	    stu.setCity(city);
	    ss.save(stu);
	    return stu;
	}

	public String del(String email)
	{

		Student stu=(Student) ss.findByEmail(email);
		if(stu!=null)
		{
		ss.delete(stu);
		
		return "deleted";
		}
		else
		{
			throw new ResourceNotFoundException("Student not found with email: " +email);
				
			}
		
	}
	public Page<Student> findByName(String name, int pagen,int pages,String[] sort)
	{
		
	   String sf=sort[0];
	   String dir=sort[1];
	   Sort.Direction dire=dir.equalsIgnoreCase("desc")?Sort.Direction.DESC:Sort.Direction.ASC;
		Pageable page=PageRequest.of(pagen, pages,Sort.by(dire,sf));
		return ss.findByName(name, page);
	}

}
