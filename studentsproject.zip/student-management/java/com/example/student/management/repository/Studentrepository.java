package com.example.student.management.repository;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.student.management.model.Student;

public interface Studentrepository extends JpaRepository<Student,Integer>{
	List<Student> findByName(String name);
	Student findByEmail(String email);
    Page<Student> findByName(String name,Pageable pagable);

}
